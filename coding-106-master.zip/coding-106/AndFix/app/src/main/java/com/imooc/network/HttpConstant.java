package com.imooc.network;

/**
 * @author: qndroid
 * @function: all url in the sdk
 * @date: 16/6/1
 */
public class HttpConstant {

    private static final String ROOT_URL = "http://imooc.com/api";
    /**
     * 检查是否有patch文件更新
     */
    public static String UPDATE_PATCH_URL = ROOT_URL + "/and_fix/update.php";

    /**
     * AndFix patch文件下载地址
     */
    public static String AND_FIX_URL = ROOT_URL + "/and_fix/patch.php";

}
