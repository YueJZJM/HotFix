package com.imooc.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.imooc.R;
import com.imooc.andfix.AndFixPatchManager;
import com.imooc.andfix.AndFixService;
import com.imooc.util.Utils;

///storage/emulated/0/Android/data/com.imooc/cache/apatch/
public class MainActivity extends AppCompatActivity {

    private static final String FILE_END = ".apatch";
    private String mPatchDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        mPatchDir = getExternalCacheDir().getAbsolutePath() + "/apatch/";
//        //是为了创建我们的我们夹
//        File file = new File(mPatchDir);
//        if (file == null || file.exists()) {
//            file.mkdir();
//        }

        startPatchService();
    }

    private void startPatchService() {
        Intent intent = new Intent(this, AndFixService.class);
        startService(intent);
    }

    //按钮点击事件1
    public void createBug(View view) {

        Utils.printLog();
    }

    //按钮点击事件2
    public void fixBug(View view) {

        AndFixPatchManager.getInstance().addPatch(getPatchName());
    }

    //构造patch文件名
    private String getPatchName() {

        return mPatchDir.concat("imooc").concat(FILE_END);
    }
}
