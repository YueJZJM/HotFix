sh ./apkpatch.sh -f new.apk -t old.apk -o outputs/ -k youdo.jks -p rzq123456 -a qndroid -e rzq123456
