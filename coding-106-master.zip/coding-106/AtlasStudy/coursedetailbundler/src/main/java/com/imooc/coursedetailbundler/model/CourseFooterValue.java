package com.imooc.coursedetailbundler.model;

import com.imooc.libcommon.BaseModel;
import java.util.ArrayList;

/**
 * @author: vision
 * @function:
 * @date: 16/9/8
 */
public class CourseFooterValue extends BaseModel {

    public ArrayList<CourseFooterDateValue> time;
    public ArrayList<CourseFooterRecommandValue> recommand;
}
