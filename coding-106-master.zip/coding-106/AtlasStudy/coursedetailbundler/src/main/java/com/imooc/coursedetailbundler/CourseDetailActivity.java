package com.imooc.coursedetailbundler;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.imooc.coursedetailbundler.adapter.CourseCommentAdapter;
import com.imooc.coursedetailbundler.model.BaseCourseModel;
import com.imooc.coursedetailbundler.view.CourseDetailFooterView;
import com.imooc.coursedetailbundler.view.CourseDetailHeaderView;
import com.imooc.libcommon.BaseActivity;
import com.imooc.libnetwork.listener.DisposeDataListener;

/**
 *
 */
public class CourseDetailActivity extends BaseActivity
    implements View.OnClickListener, AdapterView.OnItemClickListener {

  public static String COURSE_ID = "courseID";

  /**
   * UI
   */
  private ImageView mBackView;
  private ListView mListView;
  private ImageView mLoadingView;
  private RelativeLayout mBottomLayout;
  private ImageView mJianPanView;
  private EditText mInputEditView;
  private TextView mSendView;
  private CourseDetailHeaderView headerView;
  private CourseDetailFooterView footerView;
  private CourseCommentAdapter mAdapter;
  /**
   * Data
   */
  private String mCourseID;
  private BaseCourseModel mData;
  private String tempHint = "";

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_course_detail_layout);
    initData();
    initView();
    requestDeatil();
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    initData();
    initView();
    requestDeatil();
  }

  //初始化数据
  private void initData() {
    Intent intent = getIntent();
    mCourseID = intent.getStringExtra(COURSE_ID);
  }

  //初始化数据
  private void initView() {
    mBackView = (ImageView) findViewById(R.id.back_view);
    mBackView.setOnClickListener(this);
    mListView = (ListView) findViewById(R.id.comment_list_view);
    //mListView.setOnItemClickListener(this);
    mListView.setVisibility(View.GONE);
    mLoadingView = (ImageView) findViewById(R.id.loading_view);
    mLoadingView.setVisibility(View.VISIBLE);
    AnimationDrawable anim = (AnimationDrawable) mLoadingView.getDrawable();
    anim.start();

    mBottomLayout = (RelativeLayout) findViewById(R.id.bottom_layout);
    mJianPanView = (ImageView) findViewById(R.id.jianpan_view);
    mJianPanView.setOnClickListener(this);
    mInputEditView = (EditText) findViewById(R.id.comment_edit_view);
    mSendView = (TextView) findViewById(R.id.send_view);
    mSendView.setOnClickListener(this);
    mBottomLayout.setVisibility(View.GONE);

    intoEmptyState();
  }

  private void requestDeatil() {

    RequestCenter.requestCourseDetail(mCourseID, new DisposeDataListener() {
      @Override public void onSuccess(Object responseObj) {
        mData = (BaseCourseModel) responseObj;
        updateUI();
      }

      @Override public void onFailure(Object reasonObj) {

      }
    });
  }

  //根据数据填充UI
  private void updateUI() {
    mLoadingView.setVisibility(View.GONE);
    mListView.setVisibility(View.VISIBLE);
    mAdapter = new CourseCommentAdapter(this, mData.data.body);
    mListView.setAdapter(mAdapter);

    if (headerView != null) {
      mListView.removeHeaderView(headerView);
    }
    headerView = new CourseDetailHeaderView(this, mData.data.head);
    mListView.addHeaderView(headerView);
    if (footerView != null) {
      mListView.removeFooterView(footerView);
    }
    footerView = new CourseDetailFooterView(this, mData.data.footer);
    mListView.addFooterView(footerView);

    mBottomLayout.setVisibility(View.VISIBLE);
  }

  @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

  }

  public void intoEmptyState() {
    tempHint = "";
    mInputEditView.setText("");
    mInputEditView.setHint(getString(R.string.input_comment));
  }

  @Override public void onClick(View v) {
  }
}
