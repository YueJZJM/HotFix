package com.imooc.coursedetailbundler.model;

import com.imooc.libcommon.BaseModel;

/**
 * @author: vision
 * @function:
 * @date: 16/9/8
 */
public class BaseCourseModel extends BaseModel {

    public String ecode;
    public String emsg;
    public CourseModel data;
}
