package com.imooc.coursedetailbundler;

import com.imooc.coursedetailbundler.model.BaseCourseModel;
import com.imooc.libnetwork.CommonOkHttpClient;
import com.imooc.libnetwork.listener.DisposeDataHandle;
import com.imooc.libnetwork.listener.DisposeDataListener;
import com.imooc.libnetwork.request.CommonRequest;
import com.imooc.libnetwork.request.RequestParams;

/**
 * @author: vision
 * @function:
 * @date: 16/8/12
 */
public class RequestCenter {

  //根据参数发送所有post请求
  public static void postRequest(String url, RequestParams params, DisposeDataListener listener,
      Class<?> clazz) {
    CommonOkHttpClient.get(CommonRequest.
        createGetRequest(url, params), new DisposeDataHandle(listener, clazz));
  }

  private static final String ROOT_URL = "http://imooc.com/api";

  /**
   * 课程详情接口
   */
  public static String COURSE_DETAIL = ROOT_URL + "/product/course_detail.php";

  /**
   * 请求课程详情
   */
  public static void requestCourseDetail(String courseId, DisposeDataListener listener) {
    RequestParams params = new RequestParams();
    params.put("courseId", courseId);
    RequestCenter.postRequest(COURSE_DETAIL, params, listener, BaseCourseModel.class);
  }
}
