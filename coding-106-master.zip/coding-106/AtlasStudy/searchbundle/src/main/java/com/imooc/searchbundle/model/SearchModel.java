package com.imooc.searchbundle.model;

import com.imooc.libdatabase.BaseModel;
import java.util.ArrayList;

/**
 * @author: vision
 * @function:
 * @date: 16/8/12
 */
public class SearchModel extends BaseModel {

  public long uptime;
  public ArrayList<ProductModel> list;
}
