package com.imooc.thirdbundle;

import android.app.Application;

/**
 * 创建时间:  2017/06/05 17:43 <br>
 * 作者:  renzhiqiang <br>
 * 描述:
 */
public class ThirdBundleApplication extends Application {

  @Override public void onCreate() {
    super.onCreate();
  }
}
