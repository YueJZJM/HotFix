package com.imooc.thirdbundle;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * 创建时间:  2017/06/02 18:25 <br>
 * 作者:  renzhiqiang <br>
 * 描述:
 */
public class ThirdBundleActivity extends AppCompatActivity {

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_thirdbundle);
    //Toast.makeText(this, "patch success", Toast.LENGTH_LONG).show();
  }
}
