package com.imooc.pushbundle;

import android.app.Application;
import cn.jpush.android.api.JPushInterface;

/**
 * 创建时间:  2017/06/05 17:43 <br>
 * 作者:  renzhiqiang <br>
 * 描述:
 */
public class PushBundleApplication extends Application {

  @Override public void onCreate() {
    super.onCreate();
    initJPush();
  }

  private void initJPush() {
    JPushInterface.setDebugMode(true);
    JPushInterface.init(this);
  }
}
