package com.imooc.serverbundle;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class RemoteActivity extends AppCompatActivity {

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.e("renzhiqiang", "go here");
    setContentView(R.layout.activity_remote_layout);
  }
}
