package com.imooc;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.imooc.update.Updater;
import com.taobao.android.ActivityGroupDelegate;

/**
 * 整个应用的入口
 */
public class HomeActivity extends AppCompatActivity {

  private ActivityGroupDelegate mActivityDelegate;
  private ViewGroup mActivityGroupContainer;

  private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener =
      new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override public boolean onNavigationItemSelected(@NonNull MenuItem item) {
          final int menuId = item.getItemId();
          if (menuId == R.id.navigation_notifications) {
            switchToActivity("message", "com.imooc.userfragmentbundle.UserBundleActivity");
          }

          if (menuId == R.id.navigation_home) {
            switchToActivity("home", "com.imooc.homefragmentbundle.HomeBundleActivity");
          }

          if (menuId == R.id.navigation_dashboard) {
            switchToActivity("my", "com.imooc.messagefragmentbundle.MessageBundleActivity");
          }
          return true;
        }
      };

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    ((BottomNavigationView) findViewById(R.id.navigation)).
        setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    //执行动态加载
    findViewById(R.id.dynamic_update_view).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        //异步执行整个加载过程，加载完成后重启生效
        new AsyncTask<Void, Void, Void>() {
          @Override protected Void doInBackground(Void... voids) {
            Updater.update(getBaseContext());
            return null;
          }

          @Override protected void onPostExecute(Void aVoid) {
            android.os.Process.killProcess(android.os.Process.myPid());
          }
        }.execute();
      }
    });

    mActivityDelegate = new ActivityGroupDelegate(this, savedInstanceState);
    mActivityGroupContainer = (ViewGroup) findViewById(R.id.content);

    //默认路由到第一个bundle的Activity
    switchToActivity("home", "com.imooc.homefragmentbundle.HomeBundleActivity");
  }

  private void switchToActivity(String key, String activityname) {
    Intent intent = new Intent();
    intent.setClassName(getBaseContext(), activityname);
    mActivityDelegate.startChildActivity(mActivityGroupContainer, key, intent);
  }
}