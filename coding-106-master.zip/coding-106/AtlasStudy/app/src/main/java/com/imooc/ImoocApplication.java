package com.imooc;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.taobao.atlas.bundleInfo.AtlasBundleInfoManager;
import android.taobao.atlas.framework.Atlas;
import android.taobao.atlas.framework.BundleImpl;
import android.taobao.atlas.framework.BundleInstaller;
import android.taobao.atlas.runtime.ActivityTaskMgr;
import android.taobao.atlas.runtime.ClassNotFoundInterceptorCallback;
import android.text.TextUtils;
import android.widget.Toast;
import java.io.File;
import org.osgi.framework.BundleException;

/**
 * Created by qndroid on 2017/3/16.
 */

public class ImoocApplication extends Application {

  @Override public void onCreate() {

    super.onCreate();

    //应用中有远程bundle的话，必须有这里的加载方法
    Atlas.getInstance().setClassNotFoundInterceptorCallback(new ClassNotFoundInterceptorCallback() {
      @Override public Intent returnIntent(Intent intent) {
        final String className = intent.getComponent().getClassName();
        final String bundleName = AtlasBundleInfoManager.instance().
            getBundleForComponet(className);

        if (!TextUtils.isEmpty(bundleName) && !AtlasBundleInfoManager.instance()
            .isInternalBundle(bundleName)) {

          //远程bundle
          Activity activity = ActivityTaskMgr.getInstance().peekTopActivity();
          File remoteBundleFile = new File(activity.getExternalCacheDir(),
              "lib" + bundleName.replace(".", "_") + ".so");

          String path;
          if (remoteBundleFile.exists()) {
            path = remoteBundleFile.getAbsolutePath();
          } else {
            //实际开发中可以在这里弹出对话框，在bundle不存在的情况下，
            // 可以给用户一个选择，是否下载插件，当下载完毕后再次点击即可加载想要的功能
            Toast.makeText(activity, " 远程bundle不存在，请确定 : " + remoteBundleFile.getAbsolutePath(),
                Toast.LENGTH_LONG).show();
            return intent;
          }

          PackageInfo info = activity.getPackageManager().getPackageArchiveInfo(path, 0);
          try {
            Atlas.getInstance().installBundle(info.packageName, new File(path));
          } catch (BundleException e) {
            Toast.makeText(activity, " 远程bundle 安装失败，" + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
          }
          activity.startActivities(new Intent[] { intent });
        }
        return intent;
      }
    });

    //自启动还要配置这个
    Atlas.getInstance()
        .installBundleTransitivelyAsync(new String[] { "com.imooc.pushbundle" },
            new BundleInstaller.InstallListener() {
              @Override public void onFinished() {
                BundleImpl impl =
                    (BundleImpl) Atlas.getInstance().getBundle("com.imooc.pushbundle");
                if (impl != null) {
                  try {
                    impl.start();
                  } catch (BundleException e) {
                    e.printStackTrace();
                  }
                }
              }
            });
  }
}
