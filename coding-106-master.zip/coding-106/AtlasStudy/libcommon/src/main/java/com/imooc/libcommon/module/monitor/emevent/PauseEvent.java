package com.imooc.libcommon.module.monitor.emevent;

import com.imooc.libcommon.module.monitor.Monitor;
import java.util.ArrayList;

/**
 * @author: vision
 * @function:
 * @date: 16/6/13
 */
public class PauseEvent {

  public ArrayList<Monitor> content;
}
