package com.airbnb.lottie;

interface ModifierContent {
}
