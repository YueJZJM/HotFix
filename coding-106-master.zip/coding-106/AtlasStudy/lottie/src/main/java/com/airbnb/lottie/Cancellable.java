package com.airbnb.lottie;

interface Cancellable {
  void cancel();
}
