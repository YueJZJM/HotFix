package com.airbnb.lottie;

import android.graphics.Path;

interface PathContent extends Content {
  Path getPath();
}
