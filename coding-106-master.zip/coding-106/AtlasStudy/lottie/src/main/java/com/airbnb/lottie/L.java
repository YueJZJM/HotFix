package com.airbnb.lottie;

public class L {
  static final String TAG = "LOTTIE";
  public static final boolean DBG = false;
}
