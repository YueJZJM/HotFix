package com.imooc.messagefragmentbundle;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * 创建时间:  2017/06/02 18:25 <br>
 * 作者:  renzhiqiang <br>
 * 描述:
 */
public class MessageBundleActivity extends AppCompatActivity {

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_meassagebundle);
  }
}
