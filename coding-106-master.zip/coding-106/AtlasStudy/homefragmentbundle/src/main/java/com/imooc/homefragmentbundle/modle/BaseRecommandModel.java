package com.imooc.homefragmentbundle.modle;

import com.imooc.libcommon.BaseModel;

/**
 * Created by renzhiqiang on 16/8/28.
 */
public class BaseRecommandModel extends BaseModel {

    public String ecode;
    public String emsg;
    public RecommandModel data;
}
