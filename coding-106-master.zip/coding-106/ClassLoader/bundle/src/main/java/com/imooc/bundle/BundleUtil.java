package com.imooc.bundle;

import android.util.Log;

/**
 * Created by renzhiqiang on 17/5/18.
 */

public class BundleUtil {

    public static void printLog() {

        Log.e("Bundle", "I am a class in the Bundle");
    }
}
