package com.imooc.plugin;

import android.content.res.AssetManager;
import android.content.res.Resources;

import dalvik.system.DexClassLoader;

/**
 * Created by renzhiqiang on 17/5/19.
 */

public class PluginInfo {

    public DexClassLoader mClassLoader;

    public AssetManager mAssetManager;

    public Resources mResouces;



}
